const UserRepository = require("../repository/user.repository");

class AuthService{
    async login(username, password){
        const userData = await UserRepository.getByUsername(username, password);
        if(userData === null){
            return null;
        }

        if(userData.password !== password || userData.username !== username){
            return null;
        }

        return userData;
    }
}

module.exports = AuthService;