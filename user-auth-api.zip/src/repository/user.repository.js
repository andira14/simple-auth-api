const userModel = require("../model/user.model");

class UserRepository{
    static async getByUsername(username){
        return userModel.findOne({
            where:{
                username
            }
        })
    }
}

module.exports = UserRepository;